import { useState, useEffect } from 'react';
import { LandingSection } from './components/LandingSection';
import { LoveLetterSection } from './components/LoveLetterSection';
import { ReasonsSection } from './components/ReasonsSection';
import { MemoriesSection } from './components/MemoriesSection';
import { TimelineSection } from './components/TimelineSection';
import { PromisesSection } from './components/PromisesSection';
import { FinalMessage } from './components/FinalMessage';
import { FloatingHearts } from './components/FloatingHearts';
import { MusicPlayer } from './components/MusicPlayer';

export function App() {
  const [entered, setEntered] = useState(false);
  const [currentSection, setCurrentSection] = useState(0);

  useEffect(() => {
    if (entered) {
      const handleScroll = () => {
        const sections = document.querySelectorAll('.section');
        sections.forEach((section, index) => {
          const rect = section.getBoundingClientRect();
          if (rect.top >= 0 && rect.top <= window.innerHeight / 2) {
            setCurrentSection(index);
          }
        });
      };
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    }
  }, [entered]);

  if (!entered) {
    return (
      <div className="min-h-screen heart-bg flex items-center justify-center relative overflow-hidden">
        <FloatingHearts count={30} />
        
        {/* Sparkles */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute text-white animate-sparkle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                fontSize: `${Math.random() * 20 + 10}px`,
              }}
            >
              ✨
            </div>
          ))}
        </div>

        <div className="text-center z-10 px-4">
          <div className="text-6xl md:text-8xl animate-heartbeat mb-6">💕</div>
          <h1 className="font-script text-4xl md:text-6xl lg:text-7xl text-white mb-4 drop-shadow-lg">
            Happy Valentine's Day
          </h1>
          <p className="font-serif text-xl md:text-2xl text-white/90 mb-2 drop-shadow">
            My Dearest Love
          </p>
          <p className="text-white/80 mb-8 text-lg">
            I made something special for you...
          </p>
          
          <button
            onClick={() => setEntered(true)}
            className="bg-white text-pink-600 px-8 py-4 rounded-full text-xl font-semibold shadow-2xl hover:scale-110 transition-all duration-300 animate-pulse-glow"
          >
            Open Your Surprise 💝
          </button>
          
          <p className="text-white/60 text-sm mt-6">
            Click to begin our love story...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <FloatingHearts count={15} />
      <MusicPlayer />
      
      {/* Progress Indicator */}
      <div className="fixed right-4 top-1/2 -translate-y-1/2 z-50 hidden md:flex flex-col gap-2">
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <div
            key={i}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              currentSection === i 
                ? 'bg-pink-500 scale-125' 
                : 'bg-white/50 hover:bg-white/80'
            }`}
          />
        ))}
      </div>

      <LandingSection />
      <LoveLetterSection />
      <ReasonsSection />
      <MemoriesSection />
      <TimelineSection />
      <PromisesSection />
      <FinalMessage />

      {/* Footer */}
      <footer className="bg-gradient-to-r from-pink-600 to-red-500 py-8 text-center text-white">
        <p className="font-script text-3xl mb-2">Forever Yours</p>
        <p className="text-pink-200">Made with all my love 💕</p>
        <p className="text-sm text-pink-300 mt-4">Valentine's Day 2024</p>
      </footer>
    </div>
  );
}
