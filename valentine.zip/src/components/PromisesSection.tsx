export function PromisesSection() {
  const promises = [
    { icon: '🤝', promise: 'To always be your best friend and biggest supporter' },
    { icon: '👂', promise: 'To listen with my heart and understand your soul' },
    { icon: '🛡️', promise: 'To protect and cherish you every single day' },
    { icon: '😊', promise: 'To make you smile and laugh as much as possible' },
    { icon: '🌹', promise: 'To never stop romancing you, even after years together' },
    { icon: '🤗', promise: 'To be there in good times and especially in hard times' },
    { icon: '🌟', promise: 'To help you chase your dreams and be your cheerleader' },
    { icon: '💕', promise: 'To love you more with each passing day' },
  ];

  return (
    <section className="section min-h-screen bg-gradient-to-b from-pink-200 via-rose-300 to-red-300 py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="font-script text-4xl md:text-6xl text-white text-center mb-4 drop-shadow-lg">
          My Promises To You
        </h2>
        <p className="text-center text-white/90 text-xl mb-12">
          From my heart to yours 💝
        </p>
        
        <div className="grid md:grid-cols-2 gap-4">
          {promises.map((item, index) => (
            <div
              key={index}
              className="group bg-white/90 backdrop-blur-sm rounded-2xl p-5 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:bg-white"
            >
              <div className="flex items-start gap-4">
                <div className="text-4xl group-hover:animate-float">
                  {item.icon}
                </div>
                <div>
                  <p className="text-gray-700 font-medium leading-relaxed">
                    {item.promise}
                  </p>
                  <div className="mt-2 h-1 w-0 group-hover:w-full bg-gradient-to-r from-pink-400 to-rose-400 transition-all duration-500 rounded"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <div className="inline-block bg-white/95 backdrop-blur-sm rounded-3xl p-8 shadow-2xl">
            <p className="font-script text-3xl text-rose-600 mb-4">
              I Promise...
            </p>
            <p className="text-gray-700 text-lg max-w-lg">
              To hold your hand through every storm, celebrate every victory, 
              and love you unconditionally for all the days of my life.
            </p>
            <div className="mt-6 text-5xl animate-heartbeat">💍❤️💍</div>
          </div>
        </div>
      </div>
    </section>
  );
}
