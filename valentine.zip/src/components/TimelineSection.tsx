export function TimelineSection() {
  const timeline = [
    { date: 'Day 1', title: 'When We Met', desc: 'My heart knew you were special from the first moment our eyes met.', emoji: '✨' },
    { date: 'First Month', title: 'Falling in Love', desc: 'Every day I discovered something new to love about you.', emoji: '🦋' },
    { date: 'Special Day', title: 'You Said Yes', desc: 'The happiest moment of my life when you chose to be mine.', emoji: '💍' },
    { date: 'Every Day', title: 'Our Journey', desc: 'Building our life together, one beautiful day at a time.', emoji: '🏠' },
    { date: 'Today', title: 'Valentine\'s Day', desc: 'Celebrating our love and promising forever.', emoji: '💝' },
    { date: 'Forever', title: 'Our Future', desc: 'An eternity of love, laughter, and happiness awaits us.', emoji: '♾️' },
  ];

  return (
    <section className="section min-h-screen bg-gradient-to-b from-pink-100 via-rose-100 to-pink-200 py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="font-script text-4xl md:text-6xl text-rose-600 text-center mb-4">
          Our Love Story
        </h2>
        <p className="text-center text-rose-500 text-xl mb-16">
          A timeline of us 💕
        </p>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-pink-300 via-rose-400 to-red-400 transform md:-translate-x-1/2"></div>
          
          {timeline.map((item, index) => (
            <div
              key={index}
              className={`relative flex items-center mb-12 ${
                index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
              }`}
            >
              {/* Timeline dot */}
              <div className="absolute left-8 md:left-1/2 w-6 h-6 bg-white border-4 border-rose-400 rounded-full transform -translate-x-1/2 z-10 flex items-center justify-center">
                <div className="w-2 h-2 bg-rose-400 rounded-full animate-pulse"></div>
              </div>
              
              {/* Content */}
              <div className={`ml-16 md:ml-0 md:w-1/2 ${index % 2 === 0 ? 'md:pr-12 md:text-right' : 'md:pl-12'}`}>
                <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                  <div className={`flex items-center gap-3 mb-3 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                    <span className="text-3xl">{item.emoji}</span>
                    <span className="bg-gradient-to-r from-pink-500 to-rose-500 text-white text-sm px-3 py-1 rounded-full font-semibold">
                      {item.date}
                    </span>
                  </div>
                  <h3 className="font-serif text-xl text-rose-700 font-bold mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Heart at the end */}
        <div className="text-center mt-8">
          <div className="text-6xl animate-heartbeat inline-block">💖</div>
        </div>
      </div>
    </section>
  );
}
