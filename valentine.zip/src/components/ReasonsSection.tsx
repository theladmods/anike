import { useState } from 'react';

export function ReasonsSection() {
  const [revealedCount, setRevealedCount] = useState(0);
  
  const reasons = [
    { icon: '😊', reason: 'Your beautiful smile that brightens my day' },
    { icon: '💪', reason: 'How you always believe in me' },
    { icon: '🤗', reason: 'The way you hold me tight' },
    { icon: '😂', reason: 'Your adorable laugh that I love so much' },
    { icon: '💭', reason: 'How you understand me without words' },
    { icon: '🌟', reason: 'Your kindness and beautiful soul' },
    { icon: '🎯', reason: 'The way you support my dreams' },
    { icon: '☕', reason: 'Our morning coffee moments together' },
    { icon: '🌙', reason: 'Falling asleep knowing you love me' },
    { icon: '💕', reason: 'Simply because you are YOU' },
  ];

  return (
    <section className="section min-h-screen bg-gradient-to-b from-rose-200 via-pink-100 to-white py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="font-script text-4xl md:text-6xl text-rose-600 text-center mb-4">
          10 Reasons Why
        </h2>
        <p className="text-center text-rose-500 text-xl mb-12">
          I Love You More Each Day 💝
        </p>
        
        <div className="grid md:grid-cols-2 gap-4">
          {reasons.map((item, index) => (
            <div
              key={index}
              onClick={() => setRevealedCount(Math.max(revealedCount, index + 1))}
              className={`bg-white rounded-2xl p-5 shadow-lg cursor-pointer transform transition-all duration-500 hover:scale-105 border-2 ${
                index < revealedCount 
                  ? 'border-pink-300 bg-gradient-to-r from-pink-50 to-rose-50' 
                  : 'border-gray-100 hover:border-pink-200'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`text-4xl transition-all duration-500 ${index < revealedCount ? 'animate-float' : 'grayscale opacity-30'}`}>
                  {index < revealedCount ? item.icon : '🔒'}
                </div>
                <div className="flex-1">
                  <span className="text-pink-400 font-semibold">#{index + 1}</span>
                  <p className={`text-gray-700 transition-all duration-500 ${index < revealedCount ? '' : 'blur-sm'}`}>
                    {index < revealedCount ? item.reason : 'Click to reveal...'}
                  </p>
                </div>
                {index < revealedCount && (
                  <span className="text-2xl">💕</span>
                )}
              </div>
            </div>
          ))}
        </div>
        
        {revealedCount === 10 && (
          <div className="mt-12 text-center animate-fade-in-up">
            <div className="bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-2xl p-8 shadow-xl">
              <p className="text-3xl mb-2">🎉</p>
              <p className="font-script text-3xl">And a Million More Reasons!</p>
              <p className="text-pink-100 mt-2">Every single thing about you makes me fall deeper in love 💕</p>
            </div>
          </div>
        )}
        
        {revealedCount < 10 && (
          <p className="text-center text-rose-400 mt-8">
            Click each card to reveal why you're so special to me 💝
          </p>
        )}
      </div>
    </section>
  );
}
