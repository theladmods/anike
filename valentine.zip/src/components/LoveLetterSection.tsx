import { useState } from 'react';

export function LoveLetterSection() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <section className="section min-h-screen flex items-center justify-center bg-gradient-to-b from-red-400 via-pink-300 to-rose-200 py-20 px-4">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="font-script text-4xl md:text-6xl text-rose-700 mb-8">
          A Letter For You
        </h2>
        
        <div 
          className={`relative cursor-pointer transition-all duration-700 ${isOpen ? 'scale-100' : 'hover:scale-105'}`}
          onClick={() => setIsOpen(!isOpen)}
        >
          {/* Envelope */}
          <div className={`bg-gradient-to-br from-pink-100 to-rose-100 rounded-lg shadow-2xl p-8 md:p-12 border-4 border-rose-200 transition-all duration-500 ${isOpen ? 'opacity-100' : 'opacity-90'}`}>
            {!isOpen ? (
              <div className="py-12">
                <div className="text-6xl mb-4">💌</div>
                <p className="text-rose-600 font-semibold text-lg">Click to open your love letter</p>
                <div className="mt-4 flex justify-center gap-2">
                  <span className="text-2xl animate-pulse">💕</span>
                  <span className="text-2xl animate-pulse" style={{ animationDelay: '0.2s' }}>💕</span>
                  <span className="text-2xl animate-pulse" style={{ animationDelay: '0.4s' }}>💕</span>
                </div>
              </div>
            ) : (
              <div className="animate-fade-in-up">
                <div className="text-4xl mb-6">💝</div>
                <p className="font-script text-2xl text-rose-600 mb-6">My Dearest Love,</p>
                
                <div className="text-left space-y-4 text-gray-700 leading-relaxed font-light">
                  <p>
                    From the moment you came into my life, everything changed. The colors became brighter, 
                    the music sounded sweeter, and my heart found its rhythm in you.
                  </p>
                  
                  <p>
                    You are my first thought in the morning and my last wish at night. Your smile lights up 
                    my darkest days, and your love gives me strength I never knew I had.
                  </p>
                  
                  <p>
                    Every day with you is a gift that I cherish more than words could ever express. 
                    You make me want to be a better person, just to be worthy of your love.
                  </p>
                  
                  <p>
                    On this Valentine's Day, I want you to know that my love for you grows stronger 
                    with each passing moment. You are not just my partner, but my best friend, 
                    my confidant, and the love of my life.
                  </p>
                  
                  <p className="font-medium text-rose-600">
                    I love you more than yesterday, less than tomorrow, and with all of my heart forever.
                  </p>
                </div>
                
                <p className="font-script text-2xl text-rose-600 mt-8 text-right">
                  Forever & Always Yours,<br/>
                  <span className="text-3xl">💕</span>
                </p>
              </div>
            )}
          </div>
          
          {/* Wax seal */}
          <div className={`absolute -bottom-4 left-1/2 -translate-x-1/2 w-16 h-16 bg-gradient-to-br from-red-500 to-red-700 rounded-full flex items-center justify-center shadow-lg transform transition-all duration-500 ${isOpen ? 'rotate-45 opacity-50' : ''}`}>
            <span className="text-white text-2xl">💕</span>
          </div>
        </div>
      </div>
    </section>
  );
}
