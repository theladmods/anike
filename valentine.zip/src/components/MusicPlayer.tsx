import { useState } from 'react';

export function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <button
      onClick={() => setIsPlaying(!isPlaying)}
      className="fixed top-4 right-4 z-50 bg-white/90 backdrop-blur-sm p-3 rounded-full shadow-lg hover:scale-110 transition-all"
    >
      {isPlaying ? (
        <span className="text-2xl">🎵</span>
      ) : (
        <span className="text-2xl opacity-50">🔇</span>
      )}
    </button>
  );
}
