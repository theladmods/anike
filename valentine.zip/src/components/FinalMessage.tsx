import { useState } from 'react';

export function FinalMessage() {
  const [showMessage, setShowMessage] = useState(false);

  return (
    <section className="section min-h-screen bg-gradient-to-b from-red-300 via-rose-400 to-pink-500 py-20 px-4 relative overflow-hidden">
      {/* Floating decorations */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              fontSize: `${Math.random() * 30 + 20}px`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${Math.random() * 3 + 3}s`,
            }}
          >
            {['💕', '✨', '💖', '🌹', '💝'][Math.floor(Math.random() * 5)]}
          </div>
        ))}
      </div>

      <div className="max-w-3xl mx-auto text-center relative z-10">
        <div className="text-8xl md:text-9xl animate-heartbeat mb-8">💖</div>
        
        <h2 className="font-script text-5xl md:text-7xl text-white mb-6 drop-shadow-2xl">
          My Forever Love
        </h2>
        
        <p className="text-xl md:text-2xl text-white/95 mb-8 leading-relaxed drop-shadow">
          You are the missing piece I never knew I was looking for. 
          With you, I am complete.
        </p>
        
        {!showMessage ? (
          <button
            onClick={() => setShowMessage(true)}
            className="bg-white text-rose-600 px-10 py-5 rounded-full text-2xl font-semibold shadow-2xl hover:scale-110 transition-all duration-300 animate-pulse-glow"
          >
            My Final Message 💌
          </button>
        ) : (
          <div className="animate-fade-in-up">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-2xl">
              <div className="flex justify-center gap-2 mb-6">
                <span className="text-4xl animate-float" style={{ animationDelay: '0s' }}>🌹</span>
                <span className="text-4xl animate-float" style={{ animationDelay: '0.2s' }}>💕</span>
                <span className="text-4xl animate-float" style={{ animationDelay: '0.4s' }}>🌹</span>
              </div>
              
              <p className="font-script text-3xl text-rose-600 mb-6">My Darling,</p>
              
              <div className="space-y-4 text-gray-700 text-lg leading-relaxed">
                <p>
                  Words could never fully express the depth of my love for you. 
                  You are my sunshine on cloudy days, my anchor in stormy seas, 
                  and my greatest adventure.
                </p>
                
                <p>
                  Thank you for choosing me, for loving me, and for being 
                  the most incredible partner anyone could ever ask for.
                </p>
                
                <p className="font-semibold text-rose-600">
                  I love you to the moon and back, infinity times over. 
                  Happy Valentine's Day, my love! 💕
                </p>
              </div>
              
              <div className="mt-8 pt-6 border-t border-rose-200">
                <p className="font-script text-4xl text-rose-600">
                  I Love You
                </p>
                <p className="text-rose-500 mt-2">
                  Today, Tomorrow, and Forever ♾️
                </p>
                <div className="mt-4 text-6xl">
                  💑
                </div>
              </div>
            </div>
            
            {/* Confetti effect */}
            <div className="mt-8 flex justify-center gap-4">
              {['🎉', '💕', '✨', '💖', '🎊', '💝', '⭐', '💗'].map((emoji, i) => (
                <span 
                  key={i} 
                  className="text-3xl animate-bounce" 
                  style={{ animationDelay: `${i * 0.1}s` }}
                >
                  {emoji}
                </span>
              ))}
            </div>
          </div>
        )}
        
        <div className="mt-16">
          <p className="text-white/80 text-lg mb-4">With all my heart,</p>
          <p className="font-script text-4xl text-white drop-shadow-lg">Your Valentine 💘</p>
        </div>
      </div>
    </section>
  );
}
