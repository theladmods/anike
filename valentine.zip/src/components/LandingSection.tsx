export function LandingSection() {
  return (
    <section className="section min-h-screen flex items-center justify-center bg-gradient-to-b from-pink-400 via-rose-400 to-red-400 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 text-6xl animate-float" style={{ animationDelay: '0s' }}>🌹</div>
      <div className="absolute top-40 right-20 text-5xl animate-float" style={{ animationDelay: '0.5s' }}>💐</div>
      <div className="absolute bottom-20 left-20 text-4xl animate-float" style={{ animationDelay: '1s' }}>🦋</div>
      <div className="absolute bottom-40 right-10 text-6xl animate-float" style={{ animationDelay: '1.5s' }}>✨</div>
      
      <div className="text-center z-10 px-4">
        <div className="text-8xl md:text-9xl animate-heartbeat mb-8">💖</div>
        
        <h1 className="font-script text-5xl md:text-7xl lg:text-8xl text-white mb-6 drop-shadow-2xl animate-fade-in-up">
          To My Beautiful
        </h1>
        
        <p className="font-serif text-3xl md:text-4xl text-white/95 mb-4 drop-shadow-lg animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
          Valentine
        </p>
        
        <div className="flex items-center justify-center gap-4 my-8 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
          <span className="h-px w-16 bg-white/50"></span>
          <span className="text-3xl">💕</span>
          <span className="h-px w-16 bg-white/50"></span>
        </div>
        
        <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto leading-relaxed animate-fade-in-up" style={{ animationDelay: '0.9s' }}>
          Every moment with you is a treasure I hold close to my heart. 
          Today, I want to show you just how much you mean to me...
        </p>
        
        <div className="mt-12 animate-bounce">
          <svg className="w-8 h-8 mx-auto text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
          <p className="text-white/60 text-sm mt-2">Scroll to explore</p>
        </div>
      </div>
    </section>
  );
}
