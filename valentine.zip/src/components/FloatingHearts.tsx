interface FloatingHeartsProps {
  count: number;
}

export function FloatingHearts({ count }: FloatingHeartsProps) {
  const hearts = ['❤️', '💕', '💖', '💗', '💓', '💞', '💝', '🩷', '🤍', '💜'];
  
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {[...Array(count)].map((_, i) => (
        <div
          key={i}
          className="absolute"
          style={{
            left: `${Math.random() * 100}%`,
            fontSize: `${Math.random() * 30 + 15}px`,
            animation: `fall ${Math.random() * 10 + 10}s linear infinite`,
            animationDelay: `${Math.random() * 10}s`,
            opacity: 0.7,
          }}
        >
          {hearts[Math.floor(Math.random() * hearts.length)]}
        </div>
      ))}
    </div>
  );
}
