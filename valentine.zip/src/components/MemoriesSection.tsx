export function MemoriesSection() {
  const memories = [
    { emoji: '☕', title: 'Our First Date', desc: 'I was so nervous, but the moment I saw you, everything felt right.' },
    { emoji: '🎬', title: 'Movie Nights', desc: 'Cuddling on the couch, sharing popcorn, and your head on my shoulder.' },
    { emoji: '🌅', title: 'Sunsets Together', desc: 'Watching the sky change colors while holding your hand.' },
    { emoji: '🎂', title: 'Celebrations', desc: 'Every birthday, anniversary, and small win celebrated together.' },
    { emoji: '🌧️', title: 'Rainy Days', desc: 'Dancing in the rain or staying cozy indoors with you.' },
    { emoji: '🍝', title: 'Cooking Together', desc: 'Making a mess in the kitchen but having the best time.' },
  ];

  return (
    <section className="section min-h-screen bg-gradient-to-b from-white via-rose-50 to-pink-100 py-20 px-4">
      <div className="max-w-5xl mx-auto">
        <h2 className="font-script text-4xl md:text-6xl text-rose-600 text-center mb-4">
          Our Precious Memories
        </h2>
        <p className="text-center text-rose-500 text-xl mb-12">
          Moments I'll treasure forever 📸
        </p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {memories.map((memory, index) => (
            <div
              key={index}
              className="group relative bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 overflow-hidden"
            >
              {/* Decorative background */}
              <div className="absolute inset-0 bg-gradient-to-br from-pink-100/50 to-rose-100/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <div className="relative z-10">
                <div className="text-5xl mb-4 transform group-hover:scale-110 transition-transform duration-500">
                  {memory.emoji}
                </div>
                
                <h3 className="font-serif text-xl text-rose-700 font-semibold mb-2">
                  {memory.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {memory.desc}
                </p>
                
                {/* Heart decoration */}
                <div className="absolute top-4 right-4 text-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 transform group-hover:rotate-12">
                  💕
                </div>
              </div>
              
              {/* Photo placeholder effect */}
              <div className="mt-4 bg-gradient-to-br from-rose-100 to-pink-100 rounded-xl h-32 flex items-center justify-center group-hover:from-rose-200 group-hover:to-pink-200 transition-all duration-500">
                <div className="text-center">
                  <span className="text-4xl">📷</span>
                  <p className="text-rose-400 text-sm mt-2">Our Photo Here</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="font-script text-2xl text-rose-500">
            And so many more memories to create together... 💕
          </p>
        </div>
      </div>
    </section>
  );
}
